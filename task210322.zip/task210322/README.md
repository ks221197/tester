# Instruction

## SQL dump file
<b>./dvd.sql</b>

## Postman API collection
<b>./dvd.postman_collection.json</b>

## Installation

```bash
$ npm install
$ nodemon app.js
```