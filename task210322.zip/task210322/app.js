const express = require('express');
const bodyParser = require('body-parser');
const SalesRouter = require('./src/routes/sales.route')
const ProductRouter = require('./src/routes/product.route')

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


app.use('/sales', SalesRouter, function (req, res, next) {
  next()
})

app.use('/product', ProductRouter, function (req, res, next) {
  next()
})

const port = 3000
app.listen(port, function () {
  console.log(`App listening on http://localhost:${port}`)
})

app.get('/', function (req, res) {
  res.send('Hello user!!!')
})