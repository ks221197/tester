-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 21, 2022 at 12:25 PM
-- Server version: 5.7.33-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-47+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dvd`
--
CREATE DATABASE IF NOT EXISTS `dvd` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dvd`;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `sellingScenario` varchar(1100) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `sellingScenario`, `quantity`) VALUES
(1, 'mango', 100, 'per kg', 100),
(3, 'orange', 200, 'per kgs', 50);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `invoiceNumber` varchar(15) NOT NULL,
  `deliveryType` varchar(35) NOT NULL,
  `invoiceData` datetime NOT NULL,
  `product` varchar(1000) NOT NULL,
  `customer` varchar(100) NOT NULL,
  `totalPrice` int(15) NOT NULL,
  `paymentMode` varchar(100) NOT NULL,
  `updateDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `invoiceNumber`, `deliveryType`, `invoiceData`, `product`, `customer`, `totalPrice`, `paymentMode`, `updateDate`) VALUES
(1, 'DFEFCBD', '5001', '2022-03-21 11:50:28', '[{"name":"mange","price":"500","sellingScenario":"per kg","quantity":"100"},{"name":"mange","price":"500","sellingScenario":"per kg","quantity":"100"}]', '1001', 1001, '1001', NULL),
(2, 'AEGGDFB', '5001', '2022-03-21 12:05:35', '[{"id":1,"name":"mange","price":"500","sellingScenario":"per kg","quantity":"100"},{"id":3,"name":"mange","price":"500","sellingScenario":"per kg","quantity":"100"}]', '1001', 1001, '1001', NULL),
(4, 'GACCCEA', 'three wheeler', '2022-03-21 12:21:18', '[{"id":1,"name":"mango","price":"100","sellingScenario":"per kg","quantity":"20"}]', 'Rakesh Sharma', 20000, 'cash', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
