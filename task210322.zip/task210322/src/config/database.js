const mysql = require("mysql");

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "dvd",
})

connection.connect((err) => {
    if (err) {
        throw err;
    }
    console.log("MySql Connected");
});

function executeQuery(query, value = '') {
    return new Promise(function (resolve, reject) {
        console.log('executeQuery');
        connection.query(query, value, (error, results) => {
            (error) ? reject(error) : resolve(results);
        })
    })
}

module.exports=  {  connection  , executeQuery } 
