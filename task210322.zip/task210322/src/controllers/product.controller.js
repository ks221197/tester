const responseHandler = require('../helper/responseHandler');
const ProductService = require('../services/product.service');
const productService = new ProductService();

class ProductController {

    async get() {
        console.log('getController');
        try {
            const getAllProduct = await productService.get();
            return getAllProduct;
        }
        catch (error) {
            console.log('getController - error', error);
            console.log(error);
            return responseHandler.error(error)
        }
    }

    async getByName(req) {
        console.log('getByIdController');
        try {
            const id = req.params.id;
            const getProductById = await productService.getByName(id);
            return getProductById;
        }
        catch (error) {
            console.log('getByIdController - error', error);
            console.log(error);
            return responseHandler.error(error)
        }
    }

    async create(req) {
        console.log('createController');
        try {
            const data = req.body;
            const createdProduct = await productService.create(data);
            return createdProduct;
        } catch (error) {
            console.log('createController - error', error);
            console.log(error);
            return responseHandler.error(error)
        }
    }

    async update(req) {
        console.log('updateController');
        try {
            const data = req.body;
            const id = req.params.id;
            const updatedProduct = await productService.update(id, data);
            return updatedProduct;
        } catch (error) {
            console.log('updateController - error', error);
            console.log(error);
            return responseHandler.error(error)
        }
    }

    async delete(req) {
        console.log('deleteController');
        try {
            const id = req.params.id;
            const deletedProduct = await productService.delete(id);
            return deletedProduct;
        } catch (error) {
            console.log('deleteController - error', error);
            console.log(error);
            return responseHandler.error(error)
        }
    }

}

module.exports = ProductController
