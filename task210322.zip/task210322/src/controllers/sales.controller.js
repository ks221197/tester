const responseHandler = require('../helper/responseHandler');
const SalesService = require('../services/sales.service');
const salesService=new SalesService(); 

class SalesController{

    async get()
    {
        console.log('getController');
        try {
            const getAllSales=await salesService.get();
            return getAllSales;
        } 
        catch (error) {
            console.log('getController - error',error);
            console.log(error);
            return responseHandler.error(error)
        }
    }

    async getById(req)
    {
        console.log('getByIdController');
        try {
            const id=req.params.id;
            const getSalesById=await salesService.getById(id);
            return getSalesById;
        }
        catch (error) {
            console.log('getByIdController - error',error);
            console.log(error);
            return responseHandler.error(error)
        }
    }

    async create(req)
    {
        console.log('createController');
        try {
            const data=req.body;
            const createdSales=await salesService.create(data);
            return createdSales;
        } catch (error) {
            console.log('createController - error',error);
            console.log(error);
            return responseHandler.error(error)
        }
    }
    
    async update(req)
    {
        console.log('updateController');
        try {
            const data=req.body;
            const id=req.params.id;
            const updatedSales=await salesService.update(id,data);
            return updatedSales;
        } catch (error) {
            console.log('updateController - error',error);
            console.log(error);
            return responseHandler.error(error)
        }
    }
    
    async delete(req)
    {
        console.log('deleteController');
        try {
            const id=req.params.id;
            const deletedSales=await salesService.delete(id);
            return deletedSales;
        } catch (error) {
            console.log('deleteController - error',error);
            console.log(error);
            return responseHandler.error(error)
        }
    }

}

module.exports = SalesController
