module.exports = {
    databaseError:103,
    success:200,
    error:500,
    noData:450,
}
