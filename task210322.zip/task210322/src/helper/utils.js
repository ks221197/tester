function randomCode(length) {
    var code = '';
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    for (let i = 0; i < length; i++) {
        code += characters.charAt(Math.floor(Math.random() * length))
    }
    return code
}

module.exports = { randomCode }
