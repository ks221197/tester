
var express = require('express');
var router = express.Router();
var ProductController = require('../controllers/product.controller')

const productController=new ProductController(); 

router.get('/',  (req, res)=> { productController.get(req).then(function (data) {res.send(data)}) });
router.get('/:id',  (req, res)=> { productController.getByName(req).then(function (data) {res.send(data)}) });
router.post('/',  (req, res)=> { productController.create(req).then(function (data) {res.send(data)}) });
router.put('/:id',  (req, res)=> { productController.update(req).then(function (data) {res.send(data)}) });
router.delete('/:id',  (req, res)=> { productController.delete(req).then(function (data) {res.send(data)}) });


module.exports = router
