
var express = require('express');
var router = express.Router();
var SalesController = require('../controllers/sales.controller')

const salesController=new SalesController(); 

router.get('/',  (req, res)=> { salesController.get(req).then(function (data) {res.send(data)}) });
router.get('/:id',  (req, res)=> { salesController.getById(req).then(function (data) {res.send(data)}) });
router.post('/',  (req, res)=> { salesController.create(req).then(function (data) {res.send(data)}) });
router.put('/:id',  (req, res)=> { salesController.update(req).then(function (data) {res.send(data)}) });
router.delete('/:id',  (req, res)=> { salesController.delete(req).then(function (data) {res.send(data)}) });


module.exports = router
