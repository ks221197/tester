const responseHandler = require('../helper/responseHandler');
const responseStatus = require('../helper/constant');
const { executeQuery } = require('../config/database');

class ProductService {
   async get() {
      console.log('getService');
      try {
         let sql = `SELECT * FROM product`;
         const results = await executeQuery(sql);
         if (results && results.length > 0) return (responseHandler.success(responseStatus.success, 'Data retrieved successfully', results));
         return (responseHandler.error([], responseStatus.noData, 'No data found'))
      } catch (error) {
         console.log('getService : error ', error);
         return (responseHandler.error(error))
      }
   }

   async getByName(id) {
      console.log('getByNameService');
      try {
         let sql = `SELECT * FROM product WHERE name =?`;
         const results = await executeQuery(sql, id)
         if (results && results.length > 0) return (responseHandler.success(responseStatus.success, 'Data retrieved successfully', results))
         return (responseHandler.error([], responseStatus.noData, 'No data found'))
      } catch (error) {
         console.log('getByNameService : error ', error);
         return (responseHandler.error(error))
      }
   }

   async create(data) {
      console.log('createService');
      try {
         const { name, price, sellingScenario, quantity } = data
         let sql = `INSERT INTO product(name, price, sellingScenario, quantity) VALUES(?,?,?,?)`;
         const results = await executeQuery(sql, [name, price, sellingScenario, quantity])
         if (results && results.insertId !== 0) return (responseHandler.success(responseStatus.success, 'Data created successfully', { id: results.insertId, name, price, sellingScenario, quantity }))
         return (responseHandler.error([], responseStatus.noData, 'No data found'))
      } catch (error) {
         console.log('createService : error ', error);
         return (responseHandler.error(error))
      }
   }

   async update(id, data) {
      console.log('updateService');
      try {
         const { name, price, sellingScenario, quantity } = data
         let sql = `UPDATE product SET name = ? , price = ?, sellingScenario = ?, quantity = ? WHERE id = ?`;
         const results = await executeQuery(sql, [name, price, sellingScenario, quantity, id],)
         if (results && results.affectedRows === 1) return (responseHandler.success(responseStatus.success, 'Data updated successfully', results.affectedRows))
         return (responseHandler.error([], responseStatus.noData, 'No data found'))
      } catch (error) {
         console.log('updateService : error ', error);
         return (responseHandler.error(error))
      }
   }



   async updateQuantity(id, data) {
      console.log('updateQuantityService');
      try {
         const { quantity, isSold } = data

         let sql = `SELECT quantity FROM product WHERE id =?`;
         let results = await executeQuery(sql, [id]);
         let getSales = (results && results.length > 0) ? results[0].quantity : 0;
         let updatedQuantity = isSold ? (parseInt(getSales) - parseInt(quantity)) : (parseInt(getSales) + parseInt(quantity))
         updatedQuantity = updatedQuantity < 0 ? 0 : updatedQuantity

         sql = `UPDATE product SET quantity = ? WHERE id = ?`
         results = await executeQuery(sql, [updatedQuantity, id])
         if (results && results.affectedRows === 1) {
            updatedQuantity
         }
      } catch (error) {
         console.log('updateQuantityService : error ', error);
         return (responseHandler.error(error))
      }
   }

   async delete(id) {
      console.log('deleteService');
      try {
         let sql = `DELETE FROM product WHERE id = ?`;
         const results = await executeQuery(sql, [id],)
         if (results && results.affectedRows === 1) return (responseHandler.success(responseStatus.success, 'Data deleted successfully', results.affectedRows))
         return (responseHandler.error([], responseStatus.noData, 'No data found'))
      } catch (error) {
         console.log('deleteService : error ', error);
         return (responseHandler.error(error))
      }
   }
}

module.exports = ProductService
