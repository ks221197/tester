const connection = require('../config/database');
const responseHandler = require('../helper/responseHandler');
const responseStatus = require('../helper/constant');
const { randomCode } = require('../helper/utils');
const { executeQuery } = require('../config/database');
const ProductService = require('./product.service');
const productService = new ProductService();

class SalesService {
   async get() {
      console.log('getService');
      try {
         let sql = `SELECT * FROM sales`;
         const results = await executeQuery(sql);
         if (results && results.length > 0) {

            const result = results.map(result => ({
               ...result,
               product: JSON.parse(result.product)
            })
            )
            return (responseHandler.success(responseStatus.success, 'Data retrieved successfully', result));
         }
         else {
            return (responseHandler.error([], responseStatus.noData, 'No data found'))
         }
      }
      catch (error) {
         console.log('getByIdService : error ', error);
         return (responseHandler.error(error))
      }

   }

   async getById(id) {
      console.log('getByIdService');
      try {
         let sql = `SELECT * FROM sales WHERE id =?`;
         const results = await executeQuery(sql, id)
         if (results && results.length > 0) {
            const result = results.map(result => ({
               ...result,
               product: JSON.parse(result.product)
            })
            )
            return (responseHandler.success(responseStatus.success, 'Data retrieved successfully', result));
         }
         else {
            return (responseHandler.error([], responseStatus.noData, 'No data found'))
         }
      } catch (error) {
         console.log('getByIdService : error ', error);
         return (responseHandler.error(error))
      }
   }

   async create(data) {
      console.log('createService');
      try {
         const invoiceNumber = randomCode(7);
         const invoiceData = new Date();
         const { deliveryType, product, customer, totalPrice, paymentMode } = data

         let sql = `INSERT INTO sales(invoiceNumber, deliveryType, invoiceData, product, customer, totalPrice, paymentMode) VALUES(?,?,?,?,?,?,?)`;
         const results = await executeQuery(sql, [invoiceNumber, deliveryType, invoiceData, JSON.stringify(product), customer, totalPrice, paymentMode])
         if (results && results.insertId !== 0) {

            product.forEach(async(item) => {
               await productService.updateQuantity(item.id, { quantity: item.quantity, isSold: true })
            });
            return (responseHandler.success(responseStatus.success, 'Data created successfully', { id: results.insertId, invoiceNumber, deliveryType, invoiceData, product, customer, totalPrice, paymentMode }))
         }
         return (responseHandler.error([], responseStatus.noData, 'No data found'))
      } catch (error) {
         console.log('createService : error ', error);
         return (responseHandler.error(error))
      }
   }

   async update(id, data) {
      console.log('updateService');
      try {

         let oldProduct='';
         let sql = `SELECT product FROM sales WHERE id =?`;
         let results = await executeQuery(sql, id)
         if (results && results.length > 0) {
            oldProduct=JSON.parse(results[0].product)
            oldProduct.forEach(async(item) => {
               await productService.updateQuantity(item.id, { quantity: item.quantity, isSold: false })
            });
         }

         const { invoiceNumber, deliveryType, 	updateDate, product, customer, totalPrice, paymentMode } = data
          sql = `UPDATE sales SET invoiceNumber= ?, deliveryType= ?, 	updateDate= ?, product= ?, customer= ?, totalPrice= ?, paymentMode= ?  WHERE id = ?`;
          results = await executeQuery(sql, [invoiceNumber, deliveryType, 	updateDate, JSON.stringify(product), customer, totalPrice, paymentMode, id])
         if (results && results.affectedRows === 1) {
            product.forEach(async(item) => {
               await productService.updateQuantity(item.id, { quantity: item.quantity, isSold: true })
            });
            return (responseHandler.success(responseStatus.success, 'Data updated successfully', results.affectedRows))
         }
         return (responseHandler.error([], responseStatus.noData, 'No data found'))
      } catch (error) {
         console.log('updateService : error ', error);
         return (responseHandler.error(error))
      }
   }

   async delete(id) {
      console.log('deleteService');
      try {
         let oldProduct='';
         let sql = `SELECT product FROM sales WHERE id =?`;
         let results = await executeQuery(sql, id)
         if (results && results.length > 0) {
            oldProduct=JSON.parse(results[0].product)
            oldProduct.forEach(async(item) => {
               await productService.updateQuantity(item.id, { quantity: item.quantity, isSold: false })
            });
         }

          sql = `DELETE FROM sales WHERE id = ?`;
          results = await executeQuery(sql, [id],)
         if (results && results.affectedRows === 1) return (responseHandler.success(responseStatus.success, 'Data deleted successfully', results.affectedRows))
         return (responseHandler.error([], responseStatus.noData, 'No data found'))
      } catch (error) {
         console.log('deleteService : error ', error);
         return (responseHandler.error(error))
      }
   }
}

module.exports = SalesService
